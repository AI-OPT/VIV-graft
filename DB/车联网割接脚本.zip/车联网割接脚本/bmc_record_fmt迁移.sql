﻿
DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    

  DECLARE atenant_id varchar(32);
  DECLARE aservice_type varchar(32) ;
  DECLARE asource varchar(32);
  DECLARE aformat_type smallint(6);
  DECLARE afield_serial int(11);
  DECLARE afield_name varchar(32) ;
  DECLARE afield_code varchar(32) ;
  DECLARE adata_type varchar(32);
  DECLARE acomments varchar(1024);
  DECLARE anullable varchar(16) ;
  DECLARE ais_sn varchar(8);
  
--   扩展表变量

  declare i int;
  set i = 1;
  while i < 154 do

  SELECT tenant_id, service_id, format_type, field_serial, field_name, field_code, data_type, comments 
  INTO atenant_id, aservice_type, aformat_type, afield_serial, afield_name, afield_code, adata_type, acomments 
  FROM bmc_record_fmt_old where ID = i;

  IF (aservice_type = 'GPRS_CM') THEN
    INSERT INTO bmc_record_fmt(
    source,tenant_id, service_type, format_type, field_serial, field_name, field_code, data_type, comments 
    )VALUES(
    'CM',atenant_id, aservice_type, aformat_type, afield_serial, afield_name, afield_code, adata_type, acomments 
    );
  END IF;
  
  IF (aservice_type = 'GPRS_CU') THEN
    INSERT INTO bmc_record_fmt(
    source,tenant_id, service_type, format_type, field_serial, field_name, field_code, data_type, comments 
    )VALUES(
    'CU',atenant_id, aservice_type, aformat_type, afield_serial, afield_name, afield_code, adata_type, acomments 
    );
  END IF;


  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;

  call a66311a1(666);

  DROP PROCEDURE a66311a1;


