﻿DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    

  DECLARE aUNIT_PRICE_CODE varchar(32);
  DECLARE aPRICE_NAME varchar(32);
  DECLARE aFACTOR_CODE varchar(32);
  DECLARE aFEE_ITEM_CODE varchar(32) ;

--   扩展表变量



  declare i int;
  set i = 1;
  while i < 111 do

  SELECT  UNITPRICE_CODE, PRICE_NAME, FACTOR_CODE, FEE_ITEM_CODE 
  INTO aUNIT_PRICE_CODE, aPRICE_NAME, aFACTOR_CODE, aFEE_ITEM_CODE 
  FROM cp_unitprice_info_old where ID = i;

  INSERT INTO cp_unitprice_info(
  UNIT_PRICE_CODE, PRICE_NAME, FACTOR_CODE, FEE_ITEM_CODE 
  )VALUES(
  aUNIT_PRICE_CODE, aPRICE_NAME, aFACTOR_CODE, aFEE_ITEM_CODE 
  );


  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;

  call a66311a1(666);

  DROP PROCEDURE a66311a1;


