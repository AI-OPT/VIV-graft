﻿/*`bl_acctinfo` */
alter table bl_acctinfo drop column ID;
alter table bl_acctinfo add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table bl_acctinfo rename bl_acctinfo_old;

/*`bl_custinfo` */
alter table bl_custinfo drop column ID;
alter table bl_custinfo add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table bl_custinfo rename bl_custinfo_old;

/*`bl_subs_comm` */
alter table bl_subs_comm drop column ID;
alter table bl_subs_comm add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table bl_subs_comm rename bl_subs_comm_old;

/*`bl_userinfo` */
alter table bl_userinfo drop column ID;
alter table bl_userinfo add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table bl_userinfo rename bl_userinfo_old;

/*`bmc_dataquality` */
alter table bmc_dataquality drop column ID;
alter table bmc_dataquality add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table bmc_dataquality rename bmc_dataquality_old;

/*`bmc_output_info` */
alter table bmc_output_info drop column info_code;
alter table bmc_output_info add(info_code bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`info_code`));
alter table bmc_output_info rename bmc_output_info_old;

/*`bmc_record_fmt` */
alter table bmc_record_fmt drop column ID;
alter table bmc_record_fmt add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table bmc_record_fmt rename bmc_record_fmt_old;

/*`cp_price_info` */
alter table cp_price_info drop column ID;
alter table cp_price_info add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table cp_price_info rename cp_price_info_old;

/*`cp_price_detail` */
alter table cp_price_detail drop column ID;
alter table cp_price_detail add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table cp_price_detail rename cp_price_detail_old;

/*`cp_unitprice_info` */
alter table cp_unitprice_info drop column ID;
alter table cp_unitprice_info add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table cp_unitprice_info rename cp_unitprice_info_old;

/*`cp_unitprice_item` */
alter table cp_unitprice_item drop column ID;
alter table cp_unitprice_item add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table cp_unitprice_item rename cp_unitprice_item_old;

/*`cp_package_info` */
alter table cp_package_info drop column ID;
alter table cp_package_info add(ID bigint(20) NOT NULL AUTO_INCREMENT, PRIMARY KEY (`ID`));
alter table cp_package_info rename cp_package_info_old;