

DROP TABLE IF EXISTS `bl_acctinfo`;

CREATE TABLE `bl_acctinfo` (
  `ACCT_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `CUST_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `ACCT_NAME` varchar(32) COLLATE utf8_bin NOT NULL,
  `ACCT_TYPE` varchar(2) COLLATE utf8_bin NOT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `TENANT_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `SYSTEM_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `COMMENTS` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bl_custinfo` */

DROP TABLE IF EXISTS `bl_custinfo`;

CREATE TABLE `bl_custinfo` (
  `CUST_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `CUST_NAME` varchar(128) COLLATE utf8_bin NOT NULL,
  `CUST_TYPE` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `CUST_GRADE` varchar(1) COLLATE utf8_bin DEFAULT NULL,
  `PROVINCE_CODE` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `CITY_CODE` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `STATE` varchar(4) COLLATE utf8_bin NOT NULL,
  `STATE_CHG_TIME` datetime NOT NULL,
  `TENANT_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `SYSTEM_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `FACTOR_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `REMARK` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bl_subs_comm` */

DROP TABLE IF EXISTS `bl_subs_comm`;

CREATE TABLE `bl_subs_comm` (
  `SUBS_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `PRODUCT_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `SUBS_PRODUCT_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `RES_CLEAR_FLAG` varchar(1) COLLATE utf8_bin DEFAULT NULL COMMENT 'Y:清零；N-不清零。',
  `RES_CLEAR_CYCLE` varchar(1) COLLATE utf8_bin DEFAULT NULL,
  `RES_BONUS_FLAG` varchar(1) COLLATE utf8_bin DEFAULT NULL COMMENT 'Y:是赠送；N-不是赠送。',
  `RES_END_TYPE` varchar(1) COLLATE utf8_bin DEFAULT NULL COMMENT '1-自适应（与产品生失效时间保持一致）\r\n2-永久生效（2099-12-31）',
  `DEFINE_FLAG` varchar(1) COLLATE utf8_bin DEFAULT NULL COMMENT 'Y-自定义；N-不自定义。',
  `BILLING_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT 'HALF：半月套餐方式\r\nFULL：全月套餐方式\r\nOUTP：套外资费方式\r\nPDAY：首月按天收取',
  `DIS_ITEM` varchar(6) COLLATE utf8_bin DEFAULT NULL COMMENT '1：总费用优惠；',
  `DIS_TYPE` varchar(6) COLLATE utf8_bin DEFAULT NULL COMMENT 'RET：返还',
  `DIS_VALUE_TYPE` varchar(6) COLLATE utf8_bin DEFAULT NULL COMMENT 'USGP：使用量的百分比',
  `DIS_VALUE` double(14,3) DEFAULT NULL COMMENT '如果填写，必须为数字',
  `ACTIVE_TIME` datetime NOT NULL COMMENT '格式为：YYYYMMDDHH24MISS',
  `INACTIVE_TIME` datetime NOT NULL COMMENT '格式为：YYYYMMDDHH24MISS',
  `OPT_CHL_ID` varchar(7) COLLATE utf8_bin DEFAULT NULL,
  `OPT_OPER_ID` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `TENANT_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `SYSTEM_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `MSG_SEQ` varchar(32) COLLATE utf8_bin NOT NULL,
    `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bl_userinfo` */

DROP TABLE IF EXISTS `bl_userinfo`;

CREATE TABLE `bl_userinfo` (
  `CUST_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `SUBS_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `ACCT_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `USER_TYPE` varchar(32) COLLATE utf8_bin NOT NULL,
  `SERV_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `USER_STATE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `SERVICE_NUM` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `IMSI1` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `IMSI2` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `IMSI3` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `SIM_TYPE` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `SIM` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `BASIC_ORG_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `JOIN_TIME` datetime DEFAULT NULL,
  `PROVINCE_CODE` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `CITY_CODE` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `CHL_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `DEV_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `ACTIVE_TIME` datetime DEFAULT NULL,
  `INACTIVE_TIME` datetime DEFAULT NULL,
  `TENANT_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `SYSTEM_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `REMARK` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `FACTOR_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `Scout_policy_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
    `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bmc_dataquality` */

DROP TABLE IF EXISTS `bmc_dataquality`;

CREATE TABLE `bmc_dataquality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `system_id` varchar(50) COLLATE utf8_bin NOT NULL,
  `tenant_id` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `service_id` varchar(50) COLLATE utf8_bin NOT NULL,
  `dup_key` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `tb_suffix_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `script` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bmc_drquery_fieldrule` */

DROP TABLE IF EXISTS `bmc_drquery_fieldrule`;

CREATE TABLE `bmc_drquery_fieldrule` (
  `tableid` varchar(6) COLLATE utf8_bin NOT NULL,
  `field_desc` varchar(32) COLLATE utf8_bin NOT NULL,
  `field_name` varchar(32) COLLATE utf8_bin NOT NULL,
  `field_type` int(11) NOT NULL,
  `field_length` int(11) DEFAULT NULL,
  `parent_node` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `src_content` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  `default_output` int(11) DEFAULT NULL,
  `src_where` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '对应表中的字段名，表中没有则为null'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin PACK_KEYS=0;

/*Table structure for table `bmc_drquery_routerule` */

DROP TABLE IF EXISTS `bmc_drquery_routerule`;

CREATE TABLE `bmc_drquery_routerule` (
  `tenantId` varchar(32) COLLATE utf8_bin NOT NULL,
  `systemId` varchar(32) COLLATE utf8_bin NOT NULL,
  `serviceType` varchar(32) COLLATE utf8_bin NOT NULL,
  `Tableid` varchar(6) COLLATE utf8_bin NOT NULL,
  `tablename` varchar(32) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin PACK_KEYS=0;

/*Table structure for table `bmc_output_detail` */

DROP TABLE IF EXISTS `bmc_output_detail`;

CREATE TABLE `bmc_output_detail` (
  `detail_code` bigint(12) NOT NULL AUTO_INCREMENT,
  `info_code` bigint(12) NOT NULL,
  `column_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `param_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `is_key` char(1) COLLATE utf8_bin NOT NULL,
  `display_order` int(5) NOT NULL,
  `status` char(1) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`detail_code`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bmc_output_info` */

DROP TABLE IF EXISTS `bmc_output_info`;

CREATE TABLE `bmc_output_info` (
  `info_code` bigint(12) NOT NULL AUTO_INCREMENT COMMENT '标示id',
  `system_id` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '业务大类',
  `tenant_id` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `service_id` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '业务小类',
  `table_prefix` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `table_postfix` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `output_type` char(2) COLLATE utf8_bin NOT NULL COMMENT '输出类型，1:DB 2:Service',
  `output_name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `key_seq` char(1) COLLATE utf8_bin NOT NULL,
  `seq_name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` char(1) COLLATE utf8_bin NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`info_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bmc_record_fmt` */

DROP TABLE IF EXISTS `bmc_record_fmt`;

CREATE TABLE `bmc_record_fmt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `system_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `service_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `format_type` smallint(6) DEFAULT NULL,
  `field_serial` int(11) DEFAULT NULL,
  `field_name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `field_code` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `data_type` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `comments` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=481 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `cp_package_info` */

DROP TABLE IF EXISTS `cp_package_info`;

CREATE TABLE `cp_package_info` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `DETAIL_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '来自CP_PRICE_DETAIL',
  `AMOUNT` bigint(32) NOT NULL COMMENT '包内额度',
  `UNIT_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '单位编码：\r\n            MB-MB\r\n            KB-KB\r\n            60S-60秒\r\n            TIME-次\r\n            ITEM-条\r\n            ',
  `UNIT_TYPE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '单位类型：\r\n            STREAM-流量\r\n            DURATION-时长\r\n            TIMES-次数\r\n            ITEMS-条数\r\n            \r\n            Select code_name,lebel_name\r\n            From cd\r\n            Where code_type = ‘PKG_UNIT_TYPE’\r\n            ',
  `FACTOR_CODE` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '参考因素编码，自动生成，数据保存到参考因素列表中',
  `EXCEED_TYPE` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '超出后计费类型',
  `UNITPRICE_CODE` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '当超出后计费类型是单价的时候，这里就保存单价编码值，自动生成',
  `EXT_CODE` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '扩展信息编码，自动生成',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='保存计费类型为套餐包的具体信息';

/*Table structure for table `cp_price_detail` */

DROP TABLE IF EXISTS `cp_price_detail`;

CREATE TABLE `cp_price_detail` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `PRICE_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `DETAIL_NAME` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '资费明细项目的名称',
  `CHARGE_TYPE` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT 'MONFEE-月费\r\n            VPackage-语音套餐包\r\n            SPackage-短信套餐包\r\n            DPackage-数据套餐包\r\n            MPackage-虚拟币套餐包\r\n            VStep-语音阶梯\r\n            SStep-短信阶梯\r\n            DStep-数据阶梯\r\n            MStep-虚拟币阶梯\r\n            VUnit-语音单价\r\n            SUnit-短信单价\r\n            DUnit-数据单价\r\n            MUnit-虚拟币单价\r\n            \r\n            Select Code_name, label_name from CP_CODE where Code_type = ‘CHARGE_TYPE’\r\n            ',
  `ACTIVE_TIME` datetime DEFAULT NULL COMMENT '生效时间',
  `INACTIVE_TIME` datetime DEFAULT NULL COMMENT '失效时间',
  `DETAIL_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '明细编码',
  `COMMENTS` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '说明',
  `CLAZZ` varchar(500) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='保存资费包含的明细类别';

/*Table structure for table `cp_price_info` */

DROP TABLE IF EXISTS `cp_price_info`;

CREATE TABLE `cp_price_info` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `SYSTEM_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `TENANT_ID` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '租户标识',
  `PRICE_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '资费编码，全系统唯一',
  `PRICE_NAME` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '资费名称',
  `ACTIVE_TIME` datetime NOT NULL COMMENT '生效时间',
  `INACTIVE_TIME` datetime NOT NULL COMMENT '失效时间',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `OPERATOR_ID` varchar(16) COLLATE utf8_bin DEFAULT NULL COMMENT '操作员ID',
  `COMMENTS` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '说明',
  `PRODUCT_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='保存全部的资费列表，资费通过生失效时间动态切换';

/*Table structure for table `cp_unitprice_info` */

DROP TABLE IF EXISTS `cp_unitprice_info`;

CREATE TABLE `cp_unitprice_info` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `UNITPRICE_CODE` varchar(32) COLLATE utf8_bin NOT NULL,
  `PRICE_NAME` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `FACTOR_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `FEE_ITEM_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=582 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `cp_unitprice_item` */

DROP TABLE IF EXISTS `cp_unitprice_item`;

CREATE TABLE `cp_unitprice_item` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `FEE_ITEM_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `FEE_TYPE` int(1) NOT NULL COMMENT '费用类型：\r1-基本费\r\n2- 长途费3- 信息费',
  `PRICE_VALUE` bigint(20) DEFAULT NULL COMMENT '单价的值，单位：厘',
  `UNIT_TYPE` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '单价的单位类型：\r\n            6s-6秒\r\n            7s-7秒\r\n            60s-1分钟\r\n            180s-3分钟\r\n            ',
  `SUBJECT_CODE` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '费用科目编码',
  `ACTIVE_TIME` datetime NOT NULL,
  `INACTIVE_TIME` datetime NOT NULL,
  `ITEM_EXT_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '费用项扩展信息编码，自动生成，具体的扩展信息在费用项扩展信息列表中',
  `COMMENTS` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=726 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='保存单价计费类型的费用项信息';
