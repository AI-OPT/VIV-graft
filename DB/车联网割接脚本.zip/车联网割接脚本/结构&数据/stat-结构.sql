/*
SQLyog Enterprise v12.09 (64 bit)
MySQL - 5.6.24-72.2-log : Database - optbmcdb1
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`optbmcdb1` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `optbmcdb1`;

/*Table structure for table `runner_viv_viv_byd_stat_201607` */

DROP TABLE IF EXISTS `runner_viv_viv_byd_stat_201607`;

CREATE TABLE `runner_viv_viv_byd_stat_201607` (
  `CUST_ID` varchar(32) CHARACTER SET utf8 NOT NULL,
  `SUBS_ID` varchar(32) CHARACTER SET utf8 NOT NULL,
  `SERVICE_NUM` varchar(32) COLLATE utf8_bin NOT NULL,
  `SERVICE_TYPE` varchar(32) COLLATE utf8_bin NOT NULL,
  `GPRS_UP` double DEFAULT NULL,
  `GPRS_DOWN` double DEFAULT NULL,
  `DURATION` double DEFAULT NULL,
  `SOURCE` varchar(32) COLLATE utf8_bin NOT NULL,
  `UPDATE_TIME` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`CUST_ID`,`SUBS_ID`,`SOURCE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `stat_accu_rule` */

DROP TABLE IF EXISTS `stat_accu_rule`;

CREATE TABLE `stat_accu_rule` (
  `ID` int(11) NOT NULL,
  `TENANT_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `SERVICE_TYPE` varchar(32) COLLATE utf8_bin NOT NULL,
  `STAT_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `TABLE_NAME` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `GROUP_FIELDS` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `ACCU_FIELDS` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `COMMENTS` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `TABLE_NAME_RULE_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`,`TENANT_ID`,`SERVICE_TYPE`,`STAT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
