﻿

/*Table structure for table `ebilling_shm_table_db` */

DROP TABLE IF EXISTS `ebilling_shm_table_db`;

CREATE TABLE `ebilling_shm_table_db` (
  `ID` int(11) NOT NULL,
  `DB_CONNECT` varchar(64) COLLATE utf8_bin NOT NULL,
  `USER_NAME` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `PASS_WORD` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `URL` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DRIVER_CLASS_NAME` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `DB_TYPE` char(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`DB_CONNECT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `ebilling_shm_table_info` */

DROP TABLE IF EXISTS `ebilling_shm_table_info`;

CREATE TABLE `ebilling_shm_table_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `TABLE_ID` int(11) NOT NULL COMMENT '表序号',
  `IS_ENABLE` int(1) NOT NULL DEFAULT '1' COMMENT '启动的开关',
  `INDEX_KEY` varchar(128) COLLATE utf8_bin NOT NULL COMMENT '索引字段名，如果是组合键索引，通过'':''分隔，如联合索引为name:num',
  `TABLE_NAME` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '表名',
  `INDEX_MODE` int(1) NOT NULL COMMENT '索引类型，0为主键索引，1为组合索引索引\r\n逐渐索引必须有，再有组合索引',
  `STORAGE_TYPE` int(1) NOT NULL DEFAULT '1' COMMENT '存储表每一行记录的方式，0为hash，1为string',
  `INDEX_COUNT` bigint(20) NOT NULL COMMENT '索引最大值,一般为DATA_COUNT的30%',
  `DATA_COUNT` bigint(20) NOT NULL COMMENT '数据最大值',
  `IS_PARA` int(1) NOT NULL COMMENT '是否为参数表，0为非参数表，增量刷新；1为参数表，全量刷新',
  `INDEX_ID` int(11) NOT NULL COMMENT '提供表索引的编码',
  `HASH_TYPE` int(11) NOT NULL COMMENT 'hash的类型，0为数字，1为字符串',
  `LESSEE_NAME` varchar(40) COLLATE utf8_bin NOT NULL COMMENT '租户名称',
  `DB_CONNECT` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT '数据库名字',
  `tenant_id` char(8) COLLATE utf8_bin DEFAULT NULL,
  `table_key` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=151100032 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `ebilling_shm_table_record` */

DROP TABLE IF EXISTS `ebilling_shm_table_record`;

CREATE TABLE `ebilling_shm_table_record` (
  `ID` int(11) NOT NULL COMMENT '主键',
  `TABLE_ID` int(11) NOT NULL COMMENT '实体表ID',
  `TABLE_NAME` varchar(40) COLLATE utf8_bin NOT NULL,
  `FIELD_SEQ` int(11) NOT NULL COMMENT '字段序列号',
  `FIELD_NAME` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '实体字段名',
  `FIELD_TYPE` int(11) NOT NULL COMMENT '0 varchar\r\n1 int\r\n2 bigint\r\n3 date\r\n4 datetime\r\n5 timestamp',
  `FIELD_FORMAT` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '字段加载到内存的格式，如时间：yyyy-MM-dd HH:mm:ss',
  `FIELD_SIZE` int(11) DEFAULT NULL COMMENT '字段长度',
  `IS_HASHKEY` int(1) NOT NULL COMMENT '0为否，1为是，即支持索引,需要注意的是，如果该列为主键的话，那么设置为0，因为主键默认支持索引，不需要再建立索引',
  `IS_PRIMARY` int(11) NOT NULL COMMENT '是否主键',
  `SEARCH_TYPE` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '查找类型',
  `tenant_id` char(8) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
