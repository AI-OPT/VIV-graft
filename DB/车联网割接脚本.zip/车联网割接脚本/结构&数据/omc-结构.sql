/*
SQLyog Enterprise v12.09 (64 bit)
MySQL - 5.6.24-72.2-log : Database - optbmcdb1
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`optbmcdb1` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `optbmcdb1`;

/*Table structure for table `omc_avoidscout` */

DROP TABLE IF EXISTS `omc_avoidscout`;

CREATE TABLE `omc_avoidscout` (
  `AVOID_SEQ` varchar(32) DEFAULT NULL,
  `TENANT_ID` varchar(32) DEFAULT NULL,
  `SYSTEM_ID` varchar(32) DEFAULT NULL,
  `OWNER_ID` varchar(32) DEFAULT NULL,
  `OWNER_TYPE` varchar(10) DEFAULT NULL COMMENT 'subs 用户 acct 账户  cust 客户',
  `SPE_TYPE` varchar(20) DEFAULT NULL COMMENT 'STOP 停  URGE 催  STOPANDURGE 停和催  定义到用户级\n            REDLIST 红名单  如果按照账户信控 可定义到账户，如果是按照客户信控可定义到客户',
  `EFF_DATE` datetime DEFAULT NULL,
  `EXP_DATE` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='免催停信息定义到用户\n免停只能定义到用户';

/*Table structure for table `omc_bms_interface_201607` */

DROP TABLE IF EXISTS `omc_bms_interface_201607`;

CREATE TABLE `omc_bms_interface_201607` (
  `serial_no` bigint(15) DEFAULT NULL,
  `acct_id` varchar(32) DEFAULT NULL,
  `subs_id` varchar(32) DEFAULT NULL,
  `scout_type` varchar(16) DEFAULT NULL,
  `bms_data` varchar(1024) DEFAULT NULL,
  `interface_data` varchar(1024) DEFAULT NULL COMMENT '{"balance":-270.00,"pileid":"B973F8F7699","statid":"111111","iccid":"iccid10707","subs_id":"10707","scout_type":"stop"}',
  `service_type` int(4) DEFAULT NULL,
  `priority` int(4) DEFAULT NULL,
  `channel` int(4) DEFAULT NULL,
  `insert_time` datetime DEFAULT NULL,
  `deal_flag` int(1) DEFAULT NULL,
  `deal_time` datetime DEFAULT NULL,
  `remark` varchar(2000) DEFAULT NULL,
  `retry_times` int(4) DEFAULT NULL,
  `tenant_id` varchar(32) DEFAULT NULL,
  `system_id` varchar(32) DEFAULT NULL,
  `bak_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `omc_creditfee` */

DROP TABLE IF EXISTS `omc_creditfee`;

CREATE TABLE `omc_creditfee` (
  `SYSTEM_ID` varchar(32) DEFAULT NULL COMMENT '垂直产品系统的ID',
  `TENANT_ID` varchar(32) DEFAULT NULL COMMENT '垂直产品中企业或个人租户的ID',
  `CREDIT_SEQ` varchar(32) DEFAULT NULL,
  `OWNER_ID` varchar(32) DEFAULT NULL,
  `OWNER_TYPE` varchar(32) DEFAULT NULL COMMENT 'subs 用户 acct 账户  cust 客户',
  `CREDIT_TYPE` varchar(32) DEFAULT NULL COMMENT '取值范围：TMP-临时；DYM-动态',
  `CREDIT_LINE` bigint(20) DEFAULT NULL,
  `EFF_TIME` datetime DEFAULT NULL,
  `EXP_TIME` datetime DEFAULT NULL,
  `RESOURCE_CODE` varchar(10) DEFAULT NULL COMMENT 'CASH 金额，单位：分\r\nVOICE 语音的时长，单位：秒\r\nSM 短信的条数，单位：条\r\nDATA 数据的字节数，单位：K'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `omc_event` */

DROP TABLE IF EXISTS `omc_event`;

CREATE TABLE `omc_event` (
  `tenant_id` varchar(32) DEFAULT NULL,
  `source_type` varchar(20) DEFAULT NULL,
  `event_id` bigint(20) NOT NULL,
  `owner_id` varchar(32) DEFAULT NULL,
  `owner_type` varchar(10) DEFAULT NULL COMMENT '/serv 用户 /acct 账户 /cust 客户 /group 群组',
  `event_type` varchar(10) DEFAULT NULL COMMENT '/main 主业务 /sub 子业务 /time 内部调度',
  `insert_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `sco_flag` int(11) DEFAULT NULL COMMENT '0 未处理  1 处理完成',
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `omc_policy_para` */

DROP TABLE IF EXISTS `omc_policy_para`;

CREATE TABLE `omc_policy_para` (
  `system_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `policyId` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `para_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `para_type` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `para_value` varchar(32) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `omc_scout_action_define` */

DROP TABLE IF EXISTS `omc_scout_action_define`;

CREATE TABLE `omc_scout_action_define` (
  `tenant_id` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `scout_type` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  `business_code` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `scout_rule` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `inf_commond` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `sms_template` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `omc_scout_log_201607` */

DROP TABLE IF EXISTS `omc_scout_log_201607`;

CREATE TABLE `omc_scout_log_201607` (
  `logid` bigint(20) DEFAULT NULL,
  `SourceType` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `ownertype` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `owner_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `business_code` varchar(8) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `scout_type` varchar(16) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `insettime` datetime DEFAULT NULL,
  `scout_rule` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `balanceinfo` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `parainfo` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `system_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `bak_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `omc_scout_policy` */

DROP TABLE IF EXISTS `omc_scout_policy`;

CREATE TABLE `omc_scout_policy` (
  `policyId` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `policy_name` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `system_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `policyDescribe` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `policyType` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'main\r\n            subs',
  `status` varchar(3) COLLATE utf8_bin DEFAULT NULL COMMENT '1 生效  0 失效',
  `eff_date` datetime DEFAULT NULL,
  `exp_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `omc_scout_rule` */

DROP TABLE IF EXISTS `omc_scout_rule`;

CREATE TABLE `omc_scout_rule` (
  `rule_id` bigint(20) DEFAULT NULL,
  `policyId` bigint(20) DEFAULT NULL,
  `scout_rule` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `scout_type` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  `balance_floor` bigint(20) DEFAULT NULL,
  `balance_ceil` bigint(20) DEFAULT NULL,
  `owe_maxdays` int(11) DEFAULT NULL,
  `owe_mindays` int(11) DEFAULT NULL,
  `charge_ceil` bigint(20) DEFAULT NULL,
  `charge_floor` bigint(20) DEFAULT NULL,
  `cust_type` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `acct_type` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `user_type` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `cust_level` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `system_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `section_type` varchar(16) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `omc_scout_status_201607` */

DROP TABLE IF EXISTS `omc_scout_status_201607`;

CREATE TABLE `omc_scout_status_201607` (
  `sco_seq` bigint(20) DEFAULT NULL,
  `tenant_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `system_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `subs_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `acct_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `cust_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `business_code` varchar(8) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `last_status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `status_time` datetime DEFAULT NULL,
  `notify_time` datetime DEFAULT NULL,
  `notify_times` int(11) DEFAULT NULL,
  `notify_status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `notify_type` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `scout_info` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `bak_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `omc_speurgestop` */

DROP TABLE IF EXISTS `omc_speurgestop`;

CREATE TABLE `omc_speurgestop` (
  `owner_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `owner_type` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `speType` int(11) DEFAULT NULL COMMENT '1 免停 2 免催 3 免催',
  `effDate` datetime DEFAULT NULL,
  `expDate` datetime DEFAULT NULL,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `system_id` varchar(32) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `omc_tenant_para` */

DROP TABLE IF EXISTS `omc_tenant_para`;

CREATE TABLE `omc_tenant_para` (
  `system_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `para_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `para_type` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `para_value` varchar(10) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `omc_urge_interface_201607` */

DROP TABLE IF EXISTS `omc_urge_interface_201607`;

CREATE TABLE `omc_urge_interface_201607` (
  `serial_no` bigint(20) DEFAULT NULL,
  `tenant_id` varchar(32) DEFAULT NULL,
  `system_id` varchar(32) DEFAULT NULL,
  `owner_type` varchar(10) DEFAULT NULL COMMENT 'subs 用户\r\n            acct  账户\r\n            cust  客户',
  `owner_id` varchar(32) DEFAULT NULL,
  `urge_info` varchar(200) DEFAULT NULL COMMENT '预警内容采用json格式存放\r\n            {"template_id":"5054","phone":"13355558888","limit_value":"10.00","limit_type":""}',
  `insert_time` datetime DEFAULT NULL,
  `retry_times` int(11) DEFAULT NULL,
  `deal_flag` int(11) DEFAULT '9' COMMENT '0 初始\r\n            1 处理成功\r\n            2 处理失败',
  `deal_time` datetime DEFAULT NULL,
  `remark` varchar(512) DEFAULT NULL,
  `bak_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `omc_urge_status_201607` */

DROP TABLE IF EXISTS `omc_urge_status_201607`;

CREATE TABLE `omc_urge_status_201607` (
  `urge_serial` bigint(20) DEFAULT NULL,
  `owner_type` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `owner_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `urge_type` varchar(12) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `business_code` varchar(8) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `last_status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `status_time` datetime DEFAULT NULL,
  `notify_time` datetime DEFAULT NULL,
  `notify_times` int(11) DEFAULT NULL,
  `notify_status` varchar(3) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `notify_type` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `scout_info` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `system_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `bak_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `real_scout_status` */

DROP TABLE IF EXISTS `real_scout_status`;

CREATE TABLE `real_scout_status` (
  `sco_seq` bigint(20) DEFAULT NULL,
  `mvneid` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `status` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `last_status` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `subs_id` bigint(18) DEFAULT NULL,
  `acct_id` bigint(18) DEFAULT NULL,
  `cust_id` bigint(18) DEFAULT NULL,
  `status_time` datetime DEFAULT NULL,
  `notify_time` datetime DEFAULT NULL,
  `notify_times` int(11) DEFAULT NULL,
  `notify_status` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `notify_type` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `scout_info` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `statusbalance` bigint(20) DEFAULT NULL,
  `statusowedays` int(11) DEFAULT NULL,
  `statuscharge` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `real_scout_status_log` */

DROP TABLE IF EXISTS `real_scout_status_log`;

CREATE TABLE `real_scout_status_log` (
  `sco_seq` bigint(20) DEFAULT NULL,
  `mvneid` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `status` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `last_status` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `subs_id` bigint(18) DEFAULT NULL,
  `acct_id` bigint(18) DEFAULT NULL,
  `cust_id` bigint(18) DEFAULT NULL,
  `status_time` datetime DEFAULT NULL,
  `notify_time` datetime DEFAULT NULL,
  `notify_times` int(11) DEFAULT NULL,
  `notify_status` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `notify_type` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `scout_info` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `statusbalance` bigint(20) DEFAULT NULL,
  `statusowedays` int(11) DEFAULT NULL,
  `statuscharge` bigint(20) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `subs_credit_fee` */

DROP TABLE IF EXISTS `subs_credit_fee`;

CREATE TABLE `subs_credit_fee` (
  `credit_seq_id` bigint(10) NOT NULL,
  `obj_type` varchar(4) COLLATE utf8_bin NOT NULL,
  `acct_id` bigint(10) DEFAULT NULL,
  `subs_id` bigint(10) DEFAULT NULL,
  `credit_type` varchar(4) COLLATE utf8_bin NOT NULL,
  `credit_fee` bigint(14) NOT NULL,
  `active_time` datetime NOT NULL,
  `inactive_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `opt_chl_id` varchar(7) COLLATE utf8_bin DEFAULT NULL,
  `opt_oper_id` bigint(10) DEFAULT NULL,
  `remark` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`credit_seq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
