﻿
/*Table structure for table `bl_acct_info` */

DROP TABLE IF EXISTS `bl_acct_info`;

CREATE TABLE `bl_acct_info` (
  `TENANT_ID` varchar(32) DEFAULT NULL COMMENT '租户ID',
  `ACCT_ID` varchar(32) NOT NULL COMMENT '账户ID',
  `OWNER_TYPE` varchar(4) DEFAULT NULL COMMENT '属主类型,CUST：某个客户的账户\nUSER：某个用户的账户',
  `OWNER_ID` varchar(32) DEFAULT NULL COMMENT '属主ID,CUST_ID或者SUBS_ID',
  `ACCT_NAME` varchar(32) DEFAULT NULL COMMENT '账户名称',
  `ACCT_TYPE` varchar(8) DEFAULT NULL COMMENT '账户类型,PRE：预付费\nPOST：后付费',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `COMMENTS` varchar(1024) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`ACCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `bl_acctinfo_ext` */

DROP TABLE IF EXISTS `bl_acctinfo_ext`;

CREATE TABLE `bl_acctinfo_ext` (
  `EXT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增字段',
  `ACCT_ID` varchar(32) NOT NULL COMMENT '账户ID',
  `EXT_NAME` varchar(32) NOT NULL COMMENT '名称',
  `EXT_VALUE` varchar(1024) DEFAULT NULL COMMENT '值',
  PRIMARY KEY (`EXT_ID`),
  UNIQUE KEY `ACCT_ID` (`ACCT_ID`,`EXT_NAME`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `bl_custinfo` */

DROP TABLE IF EXISTS `bl_custinfo`;

CREATE TABLE `bl_custinfo` (
  `CUST_ID` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '全系统唯一',
  `TENANT_ID` varchar(32) COLLATE utf8_bin NOT NULL,
  `CUST_NAME` varchar(128) COLLATE utf8_bin NOT NULL,
  `EXT_CUST_ID` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '租户系统中设定的标识',
  `CUST_TYPE` varchar(1) COLLATE utf8_bin DEFAULT NULL COMMENT 'P-个人客户;G-单位客户',
  `CUST_GRADE` varchar(1) COLLATE utf8_bin DEFAULT NULL COMMENT '取值范围：A,B,C,D,E',
  `PROVINCE_CODE` varchar(6) COLLATE utf8_bin DEFAULT NULL COMMENT '参考省份定义表',
  `CITY_CODE` varchar(6) COLLATE utf8_bin DEFAULT NULL COMMENT '以0开头的区号',
  `STATE` varchar(16) COLLATE utf8_bin NOT NULL COMMENT 'Normal：正常;NoDoc：未返档;Register：注册;OweFee：欠费;Freeze：冻结',
  `STATE_CHG_TIME` datetime NOT NULL,
  `REMARK` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `CONTACT_NO` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `EMAIL` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `CUST_ADDRESS` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `ID_NUMBER` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`CUST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bl_custinfo_ext` */

DROP TABLE IF EXISTS `bl_custinfo_ext`;

CREATE TABLE `bl_custinfo_ext` (
  `EXT_ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `CUST_ID` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '客户ID',
  `EXT_NAME` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '扩展信息名称，取值参考：扩展因素定义表；不能重复',
  `EXT_VALUE` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '扩展信息的值，取值参考：扩展因素定义表',
  PRIMARY KEY (`EXT_ID`),
  UNIQUE KEY `CUST_ID` (`CUST_ID`,`EXT_NAME`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=122350 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bl_subs_comm` */

DROP TABLE IF EXISTS `bl_subs_comm`;

CREATE TABLE `bl_subs_comm` (
  `SUBS_ID` varchar(32) NOT NULL COMMENT '用户ID',
  `PRODUCT_ID` varchar(32) DEFAULT NULL COMMENT '产品ID',
  `SUBS_PRODUCT_ID` varchar(32) NOT NULL COMMENT '产品实例ID,当用户订购多个相同的产品的时候，需要填写这个字段用于区分不同的产品实例。全系统唯一',
  `RES_BONUS_FLAG` varchar(1) DEFAULT NULL COMMENT '赠送标识,标识该产品是否为一个赠送的产品。\n取值：Y:是赠送；\nN-不是赠送。',
  `ACTIVE_TIME` datetime NOT NULL COMMENT '生效日期',
  `INACTIVE_TIME` datetime DEFAULT NULL COMMENT '失效日期',
  `TENANT_ID` varchar(32) DEFAULT NULL COMMENT '租户ID',
  `CUST_ID` varchar(32) DEFAULT NULL COMMENT '客户ID,冗余字段,方便查询',
  `PRODUCT_TYPE` varchar(32) DEFAULT NULL COMMENT '取值范围：dr，bill',
  PRIMARY KEY (`SUBS_ID`,`SUBS_PRODUCT_ID`,`ACTIVE_TIME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `bl_subscomm_ext` */

DROP TABLE IF EXISTS `bl_subscomm_ext`;

CREATE TABLE `bl_subscomm_ext` (
  `EXT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增字段',
  `PRODUCT_ID` varchar(32) NOT NULL COMMENT '产品ID',
  `SUBS_PRODUCT_ID` varchar(32) DEFAULT NULL COMMENT '产品订购实例ID',
  `EXT_NAME` varchar(32) NOT NULL COMMENT '名称',
  `EXT_VALUE` varchar(1024) DEFAULT NULL COMMENT '值',
  `SUBS_ID` varchar(32) NOT NULL,
  PRIMARY KEY (`EXT_ID`),
  UNIQUE KEY `PRODUCT_ID` (`PRODUCT_ID`,`SUBS_PRODUCT_ID`,`EXT_NAME`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

/*Table structure for table `bl_userinfo` */

DROP TABLE IF EXISTS `bl_userinfo`;

CREATE TABLE `bl_userinfo` (
  `TENANT_ID` varchar(32) NOT NULL COMMENT '租户ID',
  `CUST_ID` varchar(32) DEFAULT NULL COMMENT '客户标识',
  `SUBS_ID` varchar(32) NOT NULL COMMENT '订购标识',
  `ACCT_ID` varchar(32) DEFAULT NULL COMMENT '帐户',
  `SERVICE_ID` varchar(64) DEFAULT NULL,
  `DEAL_TIME` datetime DEFAULT NULL COMMENT '受理时间',
  `PROVINCE_CODE` varchar(6) DEFAULT NULL COMMENT '服务标识归属省',
  `CITY_CODE` varchar(6) DEFAULT NULL COMMENT '服务标识归属地区',
  `CHL_ID` varchar(32) DEFAULT NULL COMMENT '发展渠道',
  `DEV_ID` varchar(32) DEFAULT NULL COMMENT '发展人',
  `ACTIVE_TIME` datetime NOT NULL COMMENT '生效时间',
  `INACTIVE_TIME` datetime DEFAULT NULL COMMENT '失效时间',
  `REMARK` varchar(1024) DEFAULT NULL COMMENT '备注',
  `SERV_TYPE` varchar(32) DEFAULT NULL COMMENT '业务类型',
  `USER_TYPE` varchar(32) DEFAULT NULL COMMENT '用户类型',
  `USER_STATE` varchar(32) DEFAULT NULL COMMENT '用户状态',
  `policy_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`SUBS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `bl_userinfo_ext` */

DROP TABLE IF EXISTS `bl_userinfo_ext`;

CREATE TABLE `bl_userinfo_ext` (
  `EXT_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `SUBS_ID` varchar(32) NOT NULL COMMENT '用户ID',
  `EXT_NAME` varchar(32) NOT NULL COMMENT '名称',
  `EXT_VALUE` varchar(1024) DEFAULT NULL COMMENT '值',
  PRIMARY KEY (`EXT_ID`),
  UNIQUE KEY `SUBS_ID` (`SUBS_ID`,`EXT_NAME`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

/*Table structure for table `bmc_dataquality` */

DROP TABLE IF EXISTS `bmc_dataquality`;

CREATE TABLE `bmc_dataquality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `service_type` varchar(32) COLLATE utf8_bin NOT NULL,
  `source` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `tb_suffix_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `dup_key` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bmc_output_info` */

DROP TABLE IF EXISTS `bmc_output_info`;

CREATE TABLE `bmc_output_info` (
  `info_code` bigint(12) NOT NULL AUTO_INCREMENT COMMENT '标示id',
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `service_type` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '业务类型',
  `source` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '来源',
  `table_prefix` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `table_postfix` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `output_type` char(2) COLLATE utf8_bin NOT NULL COMMENT '输出类型，1:DB 2:Service',
  `output_name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `key_seq` char(1) COLLATE utf8_bin NOT NULL,
  `seq_name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` char(1) COLLATE utf8_bin NOT NULL,
  `create_date` datetime NOT NULL,
  PRIMARY KEY (`info_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `bmc_record_fmt` */

DROP TABLE IF EXISTS `bmc_record_fmt`;

CREATE TABLE `bmc_record_fmt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `service_type` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `source` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `format_type` smallint(6) DEFAULT NULL,
  `field_serial` int(11) DEFAULT NULL,
  `field_name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `field_code` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `data_type` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `comments` varchar(1024) COLLATE utf8_bin DEFAULT NULL,
  `nullable` varchar(16) COLLATE utf8_bin DEFAULT NULL COMMENT '是否为空YES/NO',
  `is_sn` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '是否索引',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100156 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `cp_package_info` */

DROP TABLE IF EXISTS `cp_package_info`;

CREATE TABLE `cp_package_info` (
  `PACKAGE_ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `DETAIL_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '来自CP_PRICE_DETAIL',
  `AMOUNT` double DEFAULT NULL COMMENT '包内额度',
  `PRICE_VALUE` double DEFAULT NULL,
  `TOTAL_PRICE_VALUE` double DEFAULT NULL,
  `UNIT_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '单位编码：\r\n            MB-MB\r\n            KB-KB\r\n            60S-60秒\r\n            TIME-次\r\n            ITEM-条\r\n            ',
  `UNIT_TYPE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '单位类型：\r\n            STREAM-流量\r\n            DURATION-时长\r\n            TIMES-次数\r\n            ITEMS-条数\r\n            \r\n            Select code_name,lebel_name\r\n            From cd\r\n            Where code_type = ‘PKG_UNIT_TYPE’\r\n            ',
  `FACTOR_CODE` varchar(64) CHARACTER SET utf8 DEFAULT NULL COMMENT '参考因素编码，自动生成，数据保存到参考因素列表中',
  `EXCEED_TYPE` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '超出后计费类型, D：单价；T：透支',
  `UNITPRICE_CODE` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '当超出后计费类型是单价的时候，这里就保存单价编码值，自动生成',
  `EXT_CODE` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '扩展信息编码，自动生成',
  `SUBJECT_CODE` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `SERVICE_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `IS_TOTAL_PRICE` varchar(16) COLLATE utf8_bin DEFAULT NULL COMMENT '枚举值：YES 按照组合总价批价,NO 按照产品使用量批价',
  PRIMARY KEY (`PACKAGE_ID`,`DETAIL_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='保存计费类型为套餐包的具体信息';

/*Table structure for table `cp_price_detail` */

DROP TABLE IF EXISTS `cp_price_detail`;

CREATE TABLE `cp_price_detail` (
  `DETAIL_ID` bigint(20) NOT NULL COMMENT '自增字段，用于唯一索引',
  `PRICE_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '来自总表：CP_PRICE_INFO表',
  `DETAIL_NAME` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '资费明细项目的名称',
  `CHARGE_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT 'MONFEE-月费\r\n            Package-套餐包\r\n           Step-阶梯\r\n          Unit-单价\r\n            Select Code_name, label_name from CP_CODE where Code_type = ‘CHARGE_TYPE’\r\n            ',
  `ACTIVE_TIME` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '生效时间',
  `INACTIVE_TIME` datetime DEFAULT NULL COMMENT '失效时间',
  `DETAIL_CODE` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '明细编码',
  `COMMENTS` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '说明',
  `SERVICE_TYPE` varchar(32) CHARACTER SET utf8 DEFAULT '' COMMENT '业务类型',
  PRIMARY KEY (`DETAIL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='保存资费包含的明细类别';

/*Table structure for table `cp_price_info` */

DROP TABLE IF EXISTS `cp_price_info`;

CREATE TABLE `cp_price_info` (
  `PRICE_INFO_ID` bigint(20) NOT NULL COMMENT '自增字段，用于唯一索引',
  `TENANT_ID` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '租户标识',
  `PRICE_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '资费编码，全系统唯一',
  `PRICE_NAME` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT '资费名称',
  `ACTIVE_TIME` datetime NOT NULL COMMENT '生效时间',
  `INACTIVE_TIME` datetime DEFAULT NULL COMMENT '失效时间',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `OPERATOR_ID` varchar(16) COLLATE utf8_bin DEFAULT NULL COMMENT '操作员ID',
  `COMMENTS` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '说明',
  `PRODUCT_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `ACTIVE_STATUS` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `CHARGE_TYPE` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`PRICE_INFO_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='保存全部的资费列表，资费通过生失效时间动态切换';

/*Table structure for table `cp_unitprice_info` */

DROP TABLE IF EXISTS `cp_unitprice_info`;

CREATE TABLE `cp_unitprice_info` (
  `UNIT_PRICE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `UNIT_PRICE_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '单价明细编码',
  `PRICE_NAME` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '明细的名称',
  `FACTOR_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '参考因素编码',
  `FEE_ITEM_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '费用项编码',
  PRIMARY KEY (`UNIT_PRICE_ID`),
  UNIQUE KEY `UNIT_PRICE_CODE` (`UNIT_PRICE_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `cp_unitprice_item` */

DROP TABLE IF EXISTS `cp_unitprice_item`;

CREATE TABLE `cp_unitprice_item` (
  `UNIT_ITEM_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增字段，用于唯一索引',
  `FEE_ITEM_CODE` varchar(32) COLLATE utf8_bin NOT NULL COMMENT '费用项编码',
  `FEE_TYPE` int(1) NOT NULL COMMENT '费用类型',
  `PRICE_VALUE` double(20,6) DEFAULT NULL COMMENT '单价的值',
  `UNIT_TYPE_VALUE` double(20,6) DEFAULT NULL,
  `UNIT_TYPE` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '单位类型',
  `SUBJECT_CODE` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '科目编码',
  `ACTIVE_TIME` datetime NOT NULL COMMENT '生效时间',
  `INACTIVE_TIME` datetime DEFAULT NULL COMMENT '失效时间',
  `ACTIVE_STATUS` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '取值范围：,NOTEFFECT：待生效,EFFECT：生效',
  `ITEM_EXT_CODE` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT '扩展信息编码',
  `comments` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`UNIT_ITEM_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
