﻿DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    
  DECLARE aSUBS_ID varchar(32);
  DECLARE aPRODUCT_ID varchar(32);
  DECLARE aSUBS_PRODUCT_ID varchar(32) ;
  DECLARE aRES_BONUS_FLAG varchar(1);
  DECLARE aACTIVE_TIME datetime;
  DECLARE aINACTIVE_TIME datetime;
  DECLARE aTENANT_ID varchar(32) ;
  DECLARE aCUST_ID varchar(32) ;
  DECLARE aPRODUCT_TYPE varchar(32);
  
--   扩展表变量
  
  DECLARE aRES_CLEAR_FLAG varchar(1);
  declare aMSG_SEQ varchar(32);
  
  
  declare i int;
  set i = 1;
  while i < 8724 do

  SELECT TENANT_ID,SUBS_PRODUCT_ID,SUBS_ID,RES_BONUS_FLAG,PRODUCT_ID,INACTIVE_TIME,ACTIVE_TIME,RES_CLEAR_FLAG,MSG_SEQ
  INTO aTENANT_ID,aSUBS_PRODUCT_ID,aSUBS_ID,aRES_BONUS_FLAG,aPRODUCT_ID,aINACTIVE_TIME,aACTIVE_TIME,aRES_CLEAR_FLAG,aMSG_SEQ
  FROM bl_subs_comm_old where ID = i;

  INSERT INTO bl_subs_comm(
  TENANT_ID,SUBS_PRODUCT_ID,SUBS_ID,RES_BONUS_FLAG,PRODUCT_ID,INACTIVE_TIME,ACTIVE_TIME
  )VALUES(
  aTENANT_ID,aSUBS_PRODUCT_ID,aSUBS_ID,aRES_BONUS_FLAG,aPRODUCT_ID,aINACTIVE_TIME,aACTIVE_TIME
  );
  
  --    RES_CLEAR_FLAG 插入扩展表
  if isnull(aRES_CLEAR_FLAG) then
  set xid=xid+1;
  else
  INSERT INTO bl_subscomm_ext(
    SUBS_PRODUCT_ID
   ,SUBS_ID
   ,PRODUCT_ID
   ,EXT_VALUE
   ,EXT_NAME
  )values(
    aSUBS_PRODUCT_ID
   ,aSUBS_ID
   ,aPRODUCT_ID
   ,aRES_CLEAR_FLAG
   ,'RES_CLEAR_FLAG'
  );
  end if;
  
    --    MSG_SEQ 插入扩展表
  if isnull(aMSG_SEQ) then
  set xid=xid+1;
  else
  INSERT INTO bl_subscomm_ext(
    SUBS_PRODUCT_ID
   ,SUBS_ID
   ,PRODUCT_ID
   ,EXT_VALUE
   ,EXT_NAME
  )values(
    aSUBS_PRODUCT_ID
   ,aSUBS_ID
   ,aPRODUCT_ID
   ,aMSG_SEQ
   ,'MSG_SEQ'
  );
  end if;
  
  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;
  
  call a66311a1(666);
  
  DROP PROCEDURE a66311a1;
  


