﻿DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    
  DECLARE aUNIT_ITEM_ID int(11) ;
  DECLARE aFEE_ITEM_CODE varchar(32) ;
  DECLARE aFEE_TYPE int(1) ;
  DECLARE aPRICE_VALUE double(20,6) ;
  DECLARE aUNIT_TYPE_VALUE double(20,6) ;
  DECLARE aUNIT_TYPE varchar(8);
  DECLARE aSUBJECT_CODE varchar(8);
  DECLARE aACTIVE_TIME datetime ;
  DECLARE aINACTIVE_TIME datetime ;
  DECLARE aACTIVE_STATUS varchar(20);
  DECLARE aITEM_EXT_CODE varchar(32) ;
  DECLARE acomments varchar(1024) ;

--   扩展表变量



  declare i int;
  set i = 1;
  while i < 227 do

  SELECT  FEE_ITEM_CODE, FEE_TYPE, PRICE_VALUE, UNIT_TYPE, SUBJECT_CODE, ACTIVE_TIME, INACTIVE_TIME, ITEM_EXT_CODE, comments 
  INTO aFEE_ITEM_CODE, aFEE_TYPE, aPRICE_VALUE, aUNIT_TYPE, aSUBJECT_CODE, aACTIVE_TIME, aINACTIVE_TIME, aITEM_EXT_CODE, acomments 
  FROM cp_unitprice_item_old where ID = i;

  INSERT INTO cp_unitprice_item(
  FEE_ITEM_CODE, FEE_TYPE, PRICE_VALUE, UNIT_TYPE, SUBJECT_CODE, ACTIVE_TIME, INACTIVE_TIME, ITEM_EXT_CODE, comments 
  )VALUES(
  aFEE_ITEM_CODE, aFEE_TYPE, aPRICE_VALUE, aUNIT_TYPE, aSUBJECT_CODE, aACTIVE_TIME, aINACTIVE_TIME, aITEM_EXT_CODE, acomments 
  );


  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;

  call a66311a1(666);

  DROP PROCEDURE a66311a1;


