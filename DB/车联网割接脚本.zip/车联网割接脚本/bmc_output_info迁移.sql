﻿DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    
  DECLARE ainfo_code bigint(12);
  DECLARE atenant_id varchar(32);
  DECLARE aservice_type varchar(32) ;
  DECLARE asource varchar(32);
  DECLARE atable_prefix varchar(100);
  DECLARE atable_postfix varchar(100) ;
  DECLARE aoutput_type char(2) ;
  DECLARE aoutput_name varchar(100) ;
  DECLARE akey_seq char(1) ;
  DECLARE aseq_name varchar(100);
  DECLARE astatus char(1);
  DECLARE acreate_date datetime ;

--   扩展表变量


  declare i int;
  set i = 1;
  while i < 7 do

  SELECT info_code, tenant_id, service_id, table_prefix, table_postfix, output_type, output_name, key_seq, seq_name, status, create_date 
  INTO  ainfo_code, atenant_id, aservice_type, atable_prefix, atable_postfix, aoutput_type, aoutput_name, akey_seq, aseq_name, astatus, acreate_date 
  FROM bmc_output_info_old where info_code = i;

  INSERT INTO bmc_output_info(
  source, tenant_id, service_type, table_prefix, table_postfix, output_type, output_name, key_seq, seq_name, status, create_date 
  )VALUES(
  'GPRS_CM', atenant_id, aservice_type, atable_prefix, atable_postfix, aoutput_type, aoutput_name, akey_seq, aseq_name, astatus, acreate_date 
  );
  
  INSERT INTO bmc_output_info(
  source, tenant_id, service_type, table_prefix, table_postfix, output_type, output_name, key_seq, seq_name, status, create_date 
  )VALUES(
  'GPRS_CU', atenant_id, aservice_type, atable_prefix, atable_postfix, aoutput_type, aoutput_name, akey_seq, aseq_name, astatus, acreate_date 
  );
  
  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;

  call a66311a1(666);

  DROP PROCEDURE a66311a1;


