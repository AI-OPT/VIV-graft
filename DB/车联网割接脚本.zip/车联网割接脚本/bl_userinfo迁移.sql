﻿DELIMITER//
CREATE PROCEDURE a6611 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
    
  DECLARE aTENANT_ID varchar(32) ; 
  DECLARE aCUST_ID varchar(32) ; 
  DECLARE aSUBS_ID varchar(32) ; 
  DECLARE aACCT_ID varchar(32); 
  DECLARE aSERVICE_ID varchar(64);
  DECLARE aDEAL_TIME datetime; 
  DECLARE aPROVINCE_CODE varchar(6); 
  DECLARE aCITY_CODE varchar(6) ; 
  DECLARE aCHL_ID varchar(32) ; 
  DECLARE aDEV_ID varchar(32) ; 
  DECLARE aACTIVE_TIME datetime ; 
  DECLARE aINACTIVE_TIME datetime; 
  DECLARE aREMARK varchar(1024); 
  DECLARE aSERV_TYPE varchar(32); 
  DECLARE aUSER_TYPE varchar(32); 
  DECLARE aUSER_STATE varchar(32);
  DECLARE apolicy_id varchar(32);
  
--   扩展表变量
  declare aBASIC_ORG_ID varchar(32);
  declare aIMSI1 varchar(15);
  
  
  declare i int;
  set i = 1;
  while i < 8795  do
    SELECT BASIC_ORG_ID, IMSI1, TENANT_ID, CUST_ID, SUBS_ID, ACCT_ID, SERVICE_NUM, JOIN_TIME, PROVINCE_CODE, CITY_CODE, CHL_ID, DEV_ID, ACTIVE_TIME, INACTIVE_TIME, REMARK, SERV_TYPE, USER_TYPE, USER_STATE, Scout_policy_id 
    INTO aBASIC_ORG_ID, aIMSI1, aTENANT_ID,aCUST_ID,aSUBS_ID,aACCT_ID, aSERVICE_ID, aDEAL_TIME, aPROVINCE_CODE, aCITY_CODE, aCHL_ID, aDEV_ID, aACTIVE_TIME, aINACTIVE_TIME, aREMARK, aSERV_TYPE, aUSER_TYPE, aUSER_STATE, apolicy_id 
    FROM bl_userinfo_old WHERE ID = i;

    INSERT INTO bl_userinfo(
     TENANT_ID,CUST_ID,SUBS_ID,ACCT_ID,SERVICE_ID,DEAL_TIME,PROVINCE_CODE,CITY_CODE,CHL_ID,DEV_ID,ACTIVE_TIME,INACTIVE_TIME,REMARK,SERV_TYPE,USER_TYPE,USER_STATE,policy_id
  ) VALUES (
     aTENANT_ID,aCUST_ID,aSUBS_ID,aACCT_ID, aSERVICE_ID, aDEAL_TIME, aPROVINCE_CODE, aCITY_CODE, aCHL_ID, aDEV_ID, aACTIVE_TIME, aINACTIVE_TIME, aREMARK, aSERV_TYPE, aUSER_TYPE, aUSER_STATE, apolicy_id 
  );
--    BASIC_ORG_ID 插入扩展表
  if isnull(aBASIC_ORG_ID) then
  set xid=xid+1;
  else
  INSERT INTO bl_userinfo_ext(
   SUBS_ID
  ,EXT_NAME
  ,EXT_VALUE
  )values(
   aSUBS_ID
  ,'BASIC_ORG_ID'
  ,aBASIC_ORG_ID  
  );
  end if;
  
--    IMSI1 插入扩展表
  if isnull(aIMSI1) then 
  set xid=xid+1;
  else
  INSERT INTO bl_userinfo_ext(
   SUBS_ID
  ,EXT_NAME
  ,EXT_VALUE
  )values(
    aSUBS_ID
  ,'IMSI1'
  ,aIMSI1  
  );
  end if; 

  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;
  
  call a6611 (666);
  
  DROP PROCEDURE a6611;
  
