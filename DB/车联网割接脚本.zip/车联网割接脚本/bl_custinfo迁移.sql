﻿DELIMITER//
CREATE PROCEDURE a6611111 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    
  DECLARE aCUST_ID varchar(32) ; 
  DECLARE aTENANT_ID varchar(32) ;
  DECLARE aCUST_NAME varchar(128) ;
  DECLARE aEXT_CUST_ID varchar(32) ; 
  DECLARE aCUST_TYPE varchar(1) ; 
  DECLARE aCUST_GRADE varchar(1) ; 
  DECLARE aPROVINCE_CODE varchar(6) ;
  DECLARE aCITY_CODE varchar(6) ; 
  DECLARE aSTATE varchar(16) ; 
  DECLARE aSTATE_CHG_TIME datetime;
  DECLARE aREMARK varchar(1024) ;
  DECLARE aCONTACT_NO varchar(32) ;
  DECLARE aEMAIL varchar(32) ;
  DECLARE aCUST_ADDRESS varchar(128) ;
  DECLARE aID_NUMBER varchar(32) ;
  
--   扩展表变量
  declare aBASIC_ORG_ID varchar(32);
  declare aIMSI1 varchar(15);
  
  
  declare i int;
  set i = 1;
  while i < 8713  do
    SELECT CUST_ID, CUST_NAME, CUST_TYPE, CUST_GRADE, PROVINCE_CODE, CITY_CODE, STATE, STATE_CHG_TIME, TENANT_ID, REMARK 
    INTO aCUST_ID, aCUST_NAME, aCUST_TYPE, aCUST_GRADE, aPROVINCE_CODE, aCITY_CODE, aSTATE, aSTATE_CHG_TIME, aTENANT_ID, aREMARK 
    FROM bl_custinfo_old where ID = i;

    INSERT INTO bl_custinfo(
      CUST_ID, CUST_NAME, CUST_TYPE, CUST_GRADE, PROVINCE_CODE, CITY_CODE, STATE, STATE_CHG_TIME, TENANT_ID, REMARK 
    ) VALUES (
      aCUST_ID, aCUST_NAME, aCUST_TYPE, aCUST_GRADE, aPROVINCE_CODE, aCITY_CODE, aSTATE, aSTATE_CHG_TIME, aTENANT_ID, aREMARK
    );

  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;
  
  call a6611111 (666);
  
  DROP PROCEDURE a6611111;

