﻿DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    

  DECLARE aTENANT_ID varchar(32);
  DECLARE aFACTOR_CODE varchar(32);
  DECLARE aFACTOR_NAME varchar(32);
  DECLARE aFACTOR_VALUE varchar(32);

--   扩展表变量


  declare i int;
  set i = 1;
  while i < 29 do

  SELECT TENANT_ID, FACTOR_CODE, FACTOR_NAME, FACTOR_VALUE 
  INTO aTENANT_ID, aFACTOR_CODE, aFACTOR_NAME, aFACTOR_VALUE 
  FROM tsttst01.cp_factor_info_old where ID = i;

  INSERT INTO cp_factor_info(
  TENANT_ID, FACTOR_CODE, FACTOR_NAME, FACTOR_VALUE 
  )VALUES(
  aTENANT_ID, aFACTOR_CODE, aFACTOR_NAME, aFACTOR_VALUE 
  );

  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;

  call a66311a1(666);

  DROP PROCEDURE a66311a1;


