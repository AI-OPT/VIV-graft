﻿select distinct subs_id from bl_userinfo_old;

select * from bl_userinfo_old
where subs_id in (select subs_id from bl_userinfo_old group by subs_id having count(subs_id) > 1);

show procedure status;
DROP PROCEDURE sp3;
delete from bl_userinfo;
delete from bl_userinfo_ext;
delete from bl_subs_comm;
delete from cp_price_info;

select * from cp_unitprice_info_old
where unitprice_code in (select unitprice_code from cp_unitprice_info_old group by unitprice_code having count(unitprice_code) > 1);

select * from cp_unitprice_item_old
where fee_item_code in (select fee_item_code from cp_unitprice_item_old group by fee_item_code having count(fee_item_code) > 1);
