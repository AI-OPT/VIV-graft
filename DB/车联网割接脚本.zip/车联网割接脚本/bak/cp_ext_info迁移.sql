﻿DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    
  DECLARE aTENANT_ID varchar(32);
  DECLARE aSYSTEM_ID varchar(32);
  DECLARE aEXT_OWNER varchar(10) ;
  DECLARE aEXT_CODE varchar(32);
  DECLARE aEXT_TYPE varchar(18);
  DECLARE aEXT_NAME varchar(32);
  DECLARE aEXT_VALUE varchar(1024) ;

--   扩展表变量


  declare i int;
  set i = 1;
  while i < 1024 do

  SELECT  TENANT_ID, EXT_OWNER, EXT_CODE, EXT_TYPE, EXT_NAME, EXT_VALUE 
  INTO  aTENANT_ID, aEXT_OWNER, aEXT_CODE, aEXT_TYPE, aEXT_NAME, aEXT_VALUE 
  FROM tsttst01.cp_ext_info_old where ID = i;

  INSERT INTO cp_ext_info(
  TENANT_ID, EXT_OWNER, EXT_CODE, EXT_TYPE, EXT_NAME, EXT_VALUE 
  )VALUES(
  'VIV-BYD', aEXT_OWNER, aEXT_CODE, aEXT_TYPE, aEXT_NAME, aEXT_VALUE 
  );


  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;

  call a66311a1(666);

  DROP PROCEDURE a66311a1;


