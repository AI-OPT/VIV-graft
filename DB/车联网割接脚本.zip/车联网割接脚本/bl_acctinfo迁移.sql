﻿

DELIMITER//
CREATE PROCEDURE a663(x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    
  DECLARE aTENANT_ID varchar(32);
  DECLARE aACCT_ID varchar(32);
  DECLARE aOWNER_TYPE varchar(4);
  DECLARE aOWNER_ID varchar(32);
  DECLARE aACCT_NAME varchar(32);
  DECLARE aACCT_TYPE varchar(8);
  DECLARE aCREATE_TIME datetime ;
  DECLARE aCOMMENTS varchar(1024);
  
--   扩展表变量
  
  declare i int;
  set i = 1;
  while i < 8735  do
    SELECT TENANT_ID, ACCT_ID, CUST_ID, ACCT_NAME, ACCT_TYPE, CREATE_TIME, COMMENTS 
    INTO aTENANT_ID, aACCT_ID, aOWNER_ID, aACCT_NAME, aACCT_TYPE, aCREATE_TIME, aCOMMENTS 
    FROM bl_acctinfo_old where ID = i;

    INSERT INTO bl_acct_info(
      TENANT_ID, ACCT_ID, OWNER_ID, ACCT_NAME, ACCT_TYPE, CREATE_TIME, COMMENTS
    ) VALUES (
      aTENANT_ID, aACCT_ID, aOWNER_ID, aACCT_NAME, aACCT_TYPE, aCREATE_TIME, aCOMMENTS
    );

  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;
  
  call a663(666);
  
  DROP PROCEDURE a663;

