﻿DELIMITER//
CREATE PROCEDURE a66311a1 (x VARCHAR(5))
  BEGIN
  DECLARE xname VARCHAR(64) DEFAULT 'res_clear_flag';
  DECLARE newname VARCHAR(5);
  DECLARE xid INT;
--  主表变量    
  DECLARE atenant_id varchar(32);
  DECLARE aservice_type varchar(32);
  DECLARE asource varchar(32);
  DECLARE atb_suffix_key varchar(50);
  DECLARE adup_key varchar(2000);

--   扩展表变量


  declare i int;
  set i = 1;
  while i < 7 do

  SELECT  tenant_id, service_id, script, tb_suffix_key, dup_key 
  INTO atenant_id, aservice_type, asource, atb_suffix_key, adup_key 
  FROM bmc_dataquality_old where ID = i;

  INSERT INTO bmc_dataquality(
  tenant_id, service_type, source, tb_suffix_key, dup_key
  )VALUES(
  atenant_id, aservice_type, asource, atb_suffix_key, adup_key 
  );

  set i = i + 1;
  end while ;
  END;
  //
  DELIMITER;

  call a66311a1(666);

  DROP PROCEDURE a66311a1;


